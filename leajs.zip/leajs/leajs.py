# -*- coding: utf-8 -*-
#=====================#
#token menggunakan primary
#jika ada yg tidak berjalan,saya sengaja menghilangkan
# 1-3 karakter,agar kalian bisa berkembang dan tidak
# hanya teriak disaat ada kesalahan.
# jangan sombong,teruslah belajar....
"""じeaKiller ᴠ.3.ᴀ"""
from line import *
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import datetime, timedelta
from time import sleep
from threading import Thread
from io import StringIO
from multiprocessing import Pool,Process
from urllib.parse import urlencode
from random import randint
from shutil import copyfile
import subprocess, humanize, traceback
import subprocess as cmd
import platform
import requests, json
from thrift import transport, protocol, server
from line.thrift.Thrift import *
from line.thrift.TMultiplexedProcessor import *
from line.thrift.TSerialization import *
from line.thrift.TRecursive import *
from line.thrift.protocol import TCompactProtocol
from line.thrift.transport import THttpClient
import LineService, Menu, time, signal, livejson, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
from Naked.toolshed.shell import execute_js 
from random import randint
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
""" strat """

with open('tokenlea.json', 'r') as bolo:
     pin = json.load(bolo)
cl = LINE(pin['token'],appName='CHANNELCP\t2.9.1\tAndroid OS\t5.1.1')
pin['token'] = cl.authToken
k1 = LINE(pin['token2'],appName='CHANNELCP\t2.9.1\tAndroid OS\t5.1.1')
pin['token2'] = k1.authToken

print ("\n𝐋𝐞𝐚 𝐬𝐮𝐜𝐜𝐞𝐬 𝐫𝐮𝐧 ")

linePoll = OEPoll(cl)

mid = cl.getProfile().mid
Smid = k1.getProfile().mid

Zie=["u93e7efe388a1554b28e59668f7324346"]
Bots=[mid]
Lea=[Smid]
Leakiller = Zie+Bots+Lea

mulai   = time.time()

Alphatlovers = livejson.File('settSB.json')
wait = {"blacklist":{},"Member":[]}
cctv = {"cyduk":{},"point":{},"sidermem":{}}

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)

def Rchat(self,to):
    self.removeAllMessages(op.param2)
    self.sendMessage(to,"𝖇𝖊𝖗𝖍𝖆𝖘𝖎𝖑 𝖒𝖊𝖓𝖌𝖍𝖆𝖕𝖚𝖘 𝖕𝖊𝖘𝖆𝖓")

def Res(self,to):
    self.sendMessage(to,"𝖘𝖎𝖆𝖕 𝖒𝖊𝖓𝖊𝖗𝖎𝖒𝖆 𝖕𝖊𝖗𝖎𝖓𝖙𝖆𝖍 𝖇𝖔𝖘𝖘𝖖𝖚𝖍...")

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d D %02d H %02d M %02d S' % (days, hours, mins, secs)

def restartProgram():
	print ('##----- RUNNING BOT RESTARTED -----##')
	python = sys.executable
	os.execl(python, python, *sys.argv)

def command(text):
    pesan = text.lower()
    if pesan.startswith(Alphatlovers["keyCmd"]):
        cmd = pesan.replace(Alphatlovers["keyCmd"],"")
    else:
        cmd = "command"
    return cmd

def bot(op):
      try:
          global time
          global ast
          global groupParam
          global multiprocessing
          global subprocess
          global threading
          if op.type == 11:
            if op.param2 in wait["blacklist"]:
                G = cl.getCompactGroup(op.param1)
                if G.preventedJoinByTicket == False:
                    G.preventedJoinByTicket = True
                    k1.acceptGroupInvitation(op.param1)
                    k1.updateGroup(G)
                    k1.kickoutFromGroup(op.param1,[op.param2])
                    k1.leaveGroup(op.param1)
                else:
                    cl.kickoutFromGroup(op.param1,[op.param2])

          if op.type == 15:
            if op.param2 in Lea:
                try:
                    cl.inviteIntoGroup(op.param1,Lea)
                except:
                    pass
          if op.type == 17:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            k1.acceptGroupInvitation(op.param1)
                            k1.kickoutFromGroup(op.param1,[op.param2])
                            k1.leaveGroup(op.param1)
                        except:pass
                else:pass

          if op.type == 32:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            k1.acceptGroupInvitation(op.param1)
                            k1.kickoutFromGroup(op.param1,[op.param2])
                            k1.leaveGroup(op.param1)
                        except:pass
                else:pass

          if op.type == 32:
            if op.param3 in Lea:
                if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
                else:pass

            if mid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        k1.acceptGroupInvitation(op.param1)
                        k1.kickoutFromGroup(op.param1,[op.param2])
                        k1.inviteIntoGroup(op.param1,[op.param3])
                        k1.leaveGroup(op.param1)
                    except:pass
                else:pass

          if op.type == 19:
            if mid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        k1.acceptGroupInvitation(op.param1)
                        X = k1.getCompactGroup(op.param1)
                        links = X.preventedJoinByTicket
                        if links == True:
                            X.preventedJoinByTicket = False
                            k1.updateGroup(X)
                        Ticket = k1.reissueGroupTicket(op.param1)
                        for a in [cl]:
                            k1.sendMessage("%s %s" % (op.param1, Ticket))
                        time.sleep(2)
                        k1.kickoutFromGroup(op.param1,[op.param2])
                        k1.leaveGroup(op.param1)
                    except:
                        k1.acceptGroupInvitation(op.param1)
                        k1.inviteIntoGroup(op.param1,[op.param3])
                        k1.kickoutFromGroup(op.param1,[op.param2])
                        k1.leaveGroup(op.param1)
                else:pass
                return
            if Smid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        X = cl.getCompactGroup(op.param1)
                        links = X.preventedJoinByTicket
                        if links == True:
                            X.preventedJoinByTicket = False
                            cl.updateGroup(X)
                        Ticket = cl.reissueGroupTicket(op.param1)
                        for a in [k1]:
                            cl.sendMessage(a,"%s %s" % (op.param1, Ticket))
                        time.sleep(2)
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        cl.inviteIntoGroup(op.param1,[op.param3])
                        cl.kickoutFromGroup(op.param1,[op.param2])
                else:pass
                return
            if op.type == 19:
                if op.param3 in Alphatlovers["Bots"]:
                    if op.param2 not in Leakiller or op.param2 not in Alphatlovers["Bots"]:
                        wait["blacklist"][op.param2] = True
                        try:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.inviteIntoGroup(op.param1,[op.param3])
                        except:pass
                    else:pass
                    return
                if op.param3 in Zie:
                    if op.param2 not in Leakiller or op.param2 not in Alphatlovers["Bots"]:
                        wait["blacklist"][op.param2] = True
                        try:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.inviteIntoGroup(op.param1,[op.param3])
                        except:pass
                        try:
                            k1.acceptGroupInvitation(op.param1)
                            k1.findAndAddContacsByMid(op.param3)
                            k1.inviteIntoGroup(op.param1,[op.param3])
                            k1.kickoutFromGroup(op.param1,[op.param2])
                            k1.leaveGroup(op.param1)
                        except:
                            k1.acceptGroupInvitation(op.param1)
                            X = k1.getCompactGroup(op.param1)
                            links = X.preventedJoinByTicket
                            if links == True:
                                X.preventedJoinByTicket = False
                                k1.updateGroup(X)
                            Ticket = k1.reissueGroupTicket(op.param1)
                            for a in Zie:
                                k1.sendMessage(a,"%s %s" % (op.param1, Ticket))
                            time.sleep(2)
                            k1.kickoutFromGroup(op.param1,[op.param2])
                            k1.leaveGroup(op.param1)
                    else:pass
                    return

          if op.type == 0:
              return

          if op.type == 5:
            if Alphatlovers["autoAdd"] == True:
                if op.param2 not in Leakiller:
                    cl.findAndAddContactsByMid(op.param1)
                    if (Alphatlovers["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, Alphatlovers["message"])

          if op.type == 13:
            if mid in op.param3:
                if Alphatlovers["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                        cl.acceptGroupInvitation(op.param1)
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        if Alphatlovers["bypas"] == True:
                            cl.inviteIntoGroup(op.param1,Bots)
                            k1.acceptGroupInvitation(op.param1)
                            ran=[k1,cl]
                            dex=random.choice(ran)
                            x = cl.getGroup(op.param1)
                            if x.invitee == None:nama = []
                            else:nama = [contact.mid for contact in x.invitee]
                            target = []
                            for a in nama:
                              if a not in Leakiller:
                                  target.append(a)
                            cmd = 'bypass.js gid={} token={}'.format(op.param1, dek.authToken)
                            nami = [contact.mid for contact in x.members]
                            tarsih = []
                            for s in nami:
                              if s not in Leakiller:
                                  tarsih.append(s)
                            for y in target:
                                cmd += ' uid={}'.format(y)
                            for k in tarsih:
                                cmd += ' uid={}'.format(k)
                            success = execute_js(cmd)
            if Smid in op.param3:
                if Alphatlovers["bypas"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                        k1.acceptGroupInvitation(op.param1)
                        k1.leaveGroup(op.param1)
                    else:
                        k1.acceptGroupInvitation(op.param1)
                        x = k1.getGroup(op.param1)
                        if x.invitee == None:nama = []
                        else:nama = [contact.mid for contact in x.invitee]
                        target = []
                        for a in nama:
                          if a not in Leakiller:
                              target.append(a)
                        cmd = 'bypass.js gid={} token={}'.format(op.param1, k1.authToken)
                        nami = [contact.mid for contact in x.members]
                        tarsih = []
                        for s in nami:
                          if s not in Leakiller:
                              tarsih.append(s)
                        for y in target:
                            cmd += ' uid={}'.format(y)
                        for k in tarsih:
                            cmd += ' uid={}'.format(k)
                        success = execute_js(cmd)
                        k1.leaveGroup(op.param1)
          if op.type == 13:
            if op.param1 in Alphatlovers["proInvite"]:
                if op.param2 in Leakiller or op.param2 in Alphatlovers["Bots"]:
                    pass
                else:
                    try:
                        if op.param3 in Leakiller or op.param3 in Alphatlovers["Bots"]:
                            pass
                        else:
                            if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                                wait["blacklist"][op.param2] = True
                                anu = cl.getCompactGroup(op.param1)
                                if anu.invitee is not None:
                                    pipo = [a.mid for a in anu.invitee]
                                    for target in pipo:
                                      if target in op.param3 and target not in Leakiller and target not in Alphatlovers["Bots"]:
                                        wait["blacklist"][target] = True
                                        cl.cancelGroupInvitation(op.param1,[target])
                                        cl.kickoutFromGroup(op.param1,[target])
                                    cl.kickoutFromGroup(op.param1,[op.param2])
                            else:pass
                    except:
                        pass
            else:
                if op.param3 in Leakiller or op.param3 in Alphatlovers["Bots"]:pass
                else:
                    inv1 = op.param3.replace('\x1e',',')
                    inv2 = inv1.split(',')
                    for i in inv2:
                      if i in wait["blacklist"]:
                        try:
                            cl.cancelGroupInvitation(op.param1,[i])
                        except:
                            pass
                        try:
                            if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                                wait["blacklist"][op.param2] = True
                                cl.kickoutFromGroup(op.param1,[op.param2])
                        except:pass
                if op.param2 not in wait["blacklist"]:pass
                else:
                    inv1 = op.param3.replace('\x1e',',')
                    inv2 = inv1.split(',')
                    for i in inv2:
                        wait["blacklist"][i] = True
                        try:
                            cl.cancelGroupInvitation(op.param1,[i])
                        except:pass
                        try:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                        except:pass

          if op.type == 15:
            if op.param1 in Alphatlovers["leaveMsg"]:
                if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                    return
                else:
                    cl.sendMessage(op.param1, Alphatlovers["leftmsg"])

          if op.type == 17:
            if op.param1 in Alphatlovers["welcome"]:
                if op.param2 in Leakiller or op.param2 in Alphatlovers["Bots"]:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                cl.sendImageWithURL(op.param1, image)

          if op.type == 19:
            if op.param1 in Alphatlovers["proKick"]:
                if op.param2 in Leakiller or op.param2 in Alphatlovers["Bots"]:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:pass
                    try:
                        if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                            wait["blacklist"][op.param2] = True
                            if op.param3 not in wait["blacklist"]:
                                try:
                                    cl.kickoutFromGroup(op.param1,[op.param2])
                                    cl.findAndAddContactsByMid(op.param3)
                                    cl.inviteIntoGroup(op.param1,[op.param3])
                                except:pass
                            else:pass
                        else:pass
                    except:pass

          if op.type == 32:
            if op.param1 in Alphatlovers["proCancel"]:
                if op.param2 in Leakiller or op.param2 in Alphatlovers["Bots"]:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:pass
                    try:
                        if op.param2 not in Leakiller and op.param2 not in Alphatlovers["Bots"]:
                            wait["blacklist"][op.param2] = True
                            if op.param3 not in wait["blacklist"]:
                                try:
                                    cl.kickoutFromGroup(op.param1,[op.param2])
                                    cl.findAndAddContactsByMid(op.param3)
                                    cl.inviteIntoGroup(op.param1,[op.param3])
                                except:pass
                            else:pass
                        else:pass
                    except:pass

          if op.type == 55:
            try:
                if op.param1 in Alphatlovers["readPoint"]:
                   if op.param2 in Alphatlovers["readMember"][op.param1]:pass
                   else:Alphatlovers["readMember"][op.param1][op.param2] = True
                else:pass
            except:pass


          if op.type in [25,26]:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            keyt = Alphatlovers["keyCmd"]
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if Alphatlovers["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"╔══════════════\n╠•❲ᴄʜᴇᴄᴋ sᴛɪᴄᴋᴇʀ❳\n╠• sᴛᴋɪᴅ : " + msg.contentMetadata["STKID"] +"\n╠• sᴛᴋᴘᴋɢɪᴅ : " + msg.contentMetadata["STKPKGID"] + "\n╠• sᴛᴋᴠᴇʀ : " + msg.contentMetadata["STKVER"] + "\n╠• " + "line://shop/detail/" + msg.contentMetadata["STKPKGID"] +"\n╚══════════════")
               if msg.contentType == 13:
                 if Alphatlovers["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"╔══════════════\n╠• ɴᴀᴍᴀ : " + msg.contentMetadata["displayName"] + "\n╠• ᴍɪᴅ : " + msg.contentMetadata["mid"] + "\n╠• sᴛᴀᴛᴜs : " + contact.statusMessage + "\n╠• ᴘɪᴄᴛᴜʀᴇ ᴜʀʟ : http://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n╚══════════════")
                        cl.sendImageWithURL(msg.to, image)

               if msg.contentType == 13:
                 if msg._from in Zie:
                  if Alphatlovers["abots"] == True:
                    if msg.contentMetadata["mid"] in Alphatlovers["Bots"]:
                        cl.sendMessage(msg.to,"ᴡᴀs ʙᴏᴛ ғʀɪᴇɴᴅ")
                    else:
                        Alphatlovers["Bots"][msg.contentMetadata["mid"]] = True
                        cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ᴀᴅᴅ ʙᴏᴛs")
                 if Alphatlovers["dbots"] == True:
                    if msg.contentMetadata["mid"] in Alphatlovers["Bots"]:
                        del Alphatlovers["Bots"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ʀᴇᴍᴏᴠᴇ ʙᴏᴛs")
                    else:
                        cl.sendMessage(msg.to,"ᴄᴏɴᴛᴀᴄᴛ ɴᴏᴛ ɪɴ ʟɪsᴛ ʙᴏᴛs")
                 if msg._from in Zie:
                  if Alphatlovers["addadmin"] == True:
                    if msg.contentMetadata["mid"] in Alphatlovers["admin"]:
                        cl.sendMessage(msg.to,"ᴡᴀs ᴀᴅᴍɪɴ")
                    else:
                        Alphatlovers["admin"][msg.contentMetadata["mid"]] = True
                        cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ᴀᴅᴅ ᴀᴅᴍɪɴ")
                 if Alphatlovers["deladmin"] == True:
                    if msg.contentMetadata["mid"] in Alphatlovers["admin"]:
                        del Alphatlovers["admin"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ʀᴇᴍᴏᴠᴇ ᴀᴅᴍɪɴ")
                    else:
                        cl.sendMessage(msg.to,"ᴄᴏɴᴛᴀᴄᴛ ɴᴏᴛ ɪɴ ʟɪsᴛ ᴀᴅᴍɪɴ")
                 if msg._from in Zie:
                  if Alphatlovers["ablacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"ᴡᴀs ʙʟᴀᴄᴋʟɪsᴛ")
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ᴀᴅᴅ ɪɴ ʙʟᴀᴄᴋʟɪsᴛ")
                 if Alphatlovers["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ʀᴇᴍᴏᴠᴇ ʙʟᴀᴄᴋʟɪsᴛ")
                    else:
                        cl.sendMessage(msg.to,"ᴄᴏɴᴛᴀᴄᴛ ɴᴏᴛ ɪɴ ʙʟᴀᴄᴋʟɪsᴛ")

               if msg.toType == 2:
                 if msg._from in Zie:
                   if Alphatlovers["gPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     Alphatlovers["gPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     cl.sendMessage(msg.to, "sᴜᴄᴄᴇs ᴜᴘᴅᴀᴛᴇ ɢʀᴏᴜᴘ ᴘɪᴄᴛᴜᴛᴇ")

               if msg.contentType == 1:
                 if msg._from in Zie:
                   if mid in Alphatlovers["cPicture"]:
                     path = cl.downloadObjectMsg(msg_id)
                     del Alphatlovers["cPicture"][mid]
                     cl.updateProfilePicture(path)
                     cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ᴜᴘᴅᴀᴛᴇ ᴅɪsᴘʟᴀʏ ᴘɪᴄᴛᴜʀᴇ")
                   if Smid in Alphatlovers["cPicture"]:
                     path7 = k1.downloadObjectMsg(msg_id)
                     del Alphatlovers["cPicture"][Smid]
                     k1.updateProfilePicture(path7)
                     k1.sendMessage(msg.to,"sᴜᴄᴄᴇs ᴜᴘᴅᴀᴛᴇ ᴅɪsᴘʟᴀʏ ᴘɪᴄᴛᴜʀᴇ")

               if msg.contentType == 0:
                    if Alphatlovers["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        commandM = command(text)
                        commandM = commandM.strip()

                    for cmd in commandM.split('.'):
                        if msg._from in Zie:
                            if cmd.startswith("1run "):
                                cust = cmd.split("1run ")[1]
                                os.system('nohup python3 %s.py jp &'%cust)
                                cl.sendMessage(msg.to, "ʀᴜɴɴɪɴɢ ᴘʀᴏᴊᴇᴄᴛ {} sᴜᴄᴄᴇss".format(cust))
                            elif cmd.startswith("1kill "):
                               cust = cmd.split("1kill ")[1]
                               try:
                                   p = subprocess.Popen(['ps', 'ax'], stdout=subprocess.PIPE)
                                   out, err = p.communicate()
                                   for line in out.splitlines():
                                       if '%s.py'%cust in line.decode("utf-8"):
                                           pid = int(line.split(None, 1)[0])
                                           os.kill(pid, signal.SIGKILL)
                               except:
                                   pass
                               cl.sendMessage(msg.to,' succes kill %s'%cust)
                            elif cmd == '1run':
                                try:
                                    n = 0
                                    r = ''
                                    p = subprocess.Popen(['ps', 'ax'], stdout=subprocess.PIPE)
                                    out, err = p.communicate()
                                    for line in out.splitlines():
                                        if 'python3' in line.decode('utf-8'):
                                            name = line.decode('utf-8').split('python3')[1]
                                            if '.py' in name and 'lea' not in name:
                                                r += '%s: %s\n'%(n,name.replace('.py',''))
                                                n += 1
                                    if len(r) > 0:
                                        cl.sendMessage(msg.to,r.rstrip())
                                    else:
                                        cl.sendMessage(msg.to,'empy project run')
                                except:
                                    cl.sendMessage(msg.to,'error')

                            elif cmd == "friend":
                               Flist(cl,to)

                            elif cmd == 'bot:room':
                                a = []
                                b = cl.getGroup(to)
                                lss = cl.refreshContacts()
                                for i in b.members:
                                  if i.mid not in mid:
                                     a.append(i.mid)
                                     if i.mid not in lss:
                                        cl.findAndAddContactsByMid(i.mid)
                                     time.sleep(0.4)
                                if a == []:
                                   cl.sendMessage(to,"Nothing to added.")
                                else:cl.sendMessage(to,'Add whitelist')

                            elif cmd == 'kicker:room':
                                a = []
                                b = k1.getGroup(to)
                                lss = k1.refreshContacts()
                                for i in b.members:
                                  if i.mid not in Smid:
                                     a.append(i.mid)
                                     if i.mid not in lss:
                                        k1.findAndAddContactsByMid(i.mid)
                                     time.sleep(0.4)
                                if a == []:
                                   k1.sendMessage(to,"Nothing to added.")
                                else:k1.sendMessage(to,'Add whitelist')
                            elif cmd.startswith("botadd "):
                              spl = cmd.replace('botadd ','')
                              if spl == 'induk':
                                alis = cl.refreshContacts()
                                for a in Leakiller:
                                    if a != cl.profile.mid and a not in alis:
                                        time.sleep(2)
                                        try:
                                            cl.findAndAddContactsByMid(a)
                                        except:
                                            cl.sendMessage(to, "limit add")
                                cl.sendMessage(to, "Done Add")

                              if spl == 'js':
                                alis = k1.refreshContacts()
                                for a in Leakiller:
                                    if a != k1.profile.mid and a not in alis:
                                        time.sleep(2)
                                        try:
                                            k1.findAndAddContactsByMid(a)
                                        except:
                                            k1.sendMessage(to, "limit add")
                                k1.sendMessage(to, "Done Add")

                            elif cmd.startswith("tkn "):
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               if pesan == "":
                                   setKey = "" if not Alphatlovers['keyCmd'] else Alphatlovers['keyCmd']
                               else:
                                   setKey = pesan
                               cl.sendMessage(to, str(setKey))
                        if msg._from in Zie or msg._from in Alphatlovers["admin"]:
                          if cmd == "menu":cl.sendMessage(to, Menu.help(keyt))
                          if cmd == "menu1":cl.sendMessage(to, Menu.helpset(keyt))
                          if cmd == "menu2":cl.sendMessage(to, Menu.helpbot(keyt))
                          if cmd == "listorder":cl.sendMessage(to, Menu.helpbot1(keyt))

                          if cmd == "settbot":
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                eltime = time.time() - mulai
                                md = "╭━━━━━━━━━━━─\n╰━❂࿇➢ ✠͜͡τͥεͣαͫϻ ιεα ҡίԼԼεя͜͡✠ \n\n"
                                md+="  「on ==📳  <|>  📴 == off」\n\n"
                                if msg.to in Alphatlovers["proqr"]:md+="  「📳」 𝖕𝖗𝖔𝖙𝖊𝖈𝖙 𝖑𝖎𝖓𝖐 \n"
                                else:md+="  「📴」 𝖕𝖗𝖔𝖙𝖊𝖈𝖙 𝖑𝖎𝖓𝖐 \n"
                                if msg.to in Alphatlovers["proKick"]:md+="  「📳」 𝖕𝖗𝖔𝖙𝖊𝖈𝖙 𝖐𝖎𝖈𝖐 \n"
                                else:md+="  「📴」 𝖕𝖗𝖔𝖙𝖊𝖈𝖙 𝖐𝖎𝖈𝖐 \n"
                                if msg.to in Alphatlovers["proCancel"]:md+="  「📳」 𝖕𝖗𝖔𝖙𝖊𝖈𝖙 𝖈𝖆𝖓𝖈𝖊𝖑 \n"
                                else:md+="  「📴」 𝖕𝖗𝖔𝖙𝖊𝖈𝖙 𝖈𝖆𝖓𝖈𝖊𝖑 \n"
                                if msg.to in Alphatlovers["proInvite"]:md+="  「📳」 𝖕𝖗𝖔𝖙𝖊𝖈𝖙 𝖎𝖓𝖛𝖎𝖙𝖊 \n"
                                else:md+="  「📴」 𝖕𝖗𝖔𝖙𝖊𝖈𝖙 𝖎𝖓𝖛𝖎𝖙𝖊 \n"
                                if msg.to in Alphatlovers["intaPoint"]:md+="  「📳」 𝖘𝖊𝖙 𝖆𝖚𝖙𝖔 𝖕𝖔𝖎𝖓𝖙 \n"
                                else:md+="  「📴」 𝖘𝖊𝖙 𝖆𝖚𝖙𝖔 𝖕𝖔𝖎𝖓𝖙 \n"
                                if Alphatlovers["bypas"] == True:md+="  「📳」 𝖒𝖔𝖉𝖊 𝖇𝖞𝖕𝖆𝖘𝖘 \n"
                                else:md+="  「📴」 𝖒𝖔𝖉𝖊 𝖇𝖞𝖕𝖆𝖘𝖘 \n"
                                if Alphatlovers["autoJoin"] == True:md+="  「📳」 𝖆'𝖏𝖔𝖎𝖓 𝖌𝖗𝖔𝖚𝖕 \n"
                                else:md+="  「📴」 𝖆'𝖏𝖔𝖎𝖓 𝖌𝖗𝖔𝖚𝖕 \n"
                                if Alphatlovers["autoJoinTicket"] == True:md+="  「📳」 𝖆'𝖏𝖔𝖎𝖓 𝖙𝖎𝖈𝖐𝖊𝖙 \n"
                                else:md+="  「📴」 𝖆'𝖏𝖔𝖎𝖓 𝖙𝖎𝖈𝖐𝖊𝖙 \n"
                                if Alphatlovers["contact"] == True:md+="  「📳」 𝖈𝖍𝖊𝖈𝖐 𝖈𝖔𝖓𝖙𝖆𝖈𝖙 \n"
                                else:md+="  「📴」 𝖈𝖍𝖊𝖈𝖐 𝖈𝖔𝖓𝖙𝖆𝖈𝖙 \n"
                                if Alphatlovers["sticker"] == True:md+="  「📳」 𝖈𝖍𝖊𝖈𝖐 𝖘𝖙𝖎𝖈𝖐𝖊𝖗 \n"
                                else:md+="  「📴」 𝖈𝖍𝖊𝖈𝖐 𝖘𝖙𝖎𝖈𝖐𝖊𝖗 \n"
                                if Alphatlovers["detectMention"] == True:md+="  「📳」 𝖗𝖊𝖘𝖕𝖔𝖓 𝖒𝖊𝖓𝖙𝖎𝖔𝖓 \n"
                                else:md+="  「📴」 𝖗𝖊𝖘𝖕𝖔𝖓 𝖒𝖊𝖓𝖙𝖎𝖔𝖓 \n"
                                if Alphatlovers["autoAdd"] == True:md+="  「📳」 𝖆𝖉𝖉 𝖈𝖔𝖓𝖙𝖆𝖈𝖙 \n"
                                else:md+="  「📴」 𝖆𝖉𝖉 𝖈𝖔𝖓𝖙𝖆𝖈𝖙 \n"
                                if Alphatlovers["LikeOn"] == True:md+="  「📳」 𝖑𝖎𝖐𝖊 & 𝖈𝖔𝖒𝖒𝖊𝖓𝖙 \n"
                                else:md+="  「📴」 𝖑𝖎𝖐𝖊 & 𝖈𝖔𝖒𝖒𝖊𝖓𝖙 \n"
                                if Alphatlovers["checkPost"] == True:md+="  「📳」 𝖈𝖍𝖊𝖈𝖐 𝖕𝖔𝖘𝖙 \n"
                                else:md+="  「📴」 𝖈𝖍𝖊𝖈𝖐 𝖕𝖔𝖘𝖙 \n"
                                if Alphatlovers["Unsend"] == True:md+="  「📳」 𝖉'𝖚𝖓𝖘𝖊𝖓𝖉 𝖒𝖊𝖘𝖘𝖆𝖌𝖊 \n"
                                else:md+="  「📴」 𝖉'𝖚𝖓𝖘𝖊𝖓𝖉 𝖒𝖊𝖘𝖘𝖆𝖌𝖊 \n"
                                if msg.to in Alphatlovers["welcome"]:md+="  「📳」 𝖒𝖘𝖌 𝖜𝖊𝖑𝖈𝖔𝖒𝖊 \n"
                                else:md+="  「📴」 𝖒𝖘𝖌 𝖜𝖊𝖑𝖈𝖔𝖒𝖊 \n"
                                if msg.to in Alphatlovers["leaveMsg"]:md+="  「📳」 𝖒𝖘𝖌 𝖑𝖊𝖆𝖛𝖊 \n"
                                else:
                                    md+="  「📴」 𝖒𝖘𝖌 𝖑𝖊𝖆𝖛𝖊 \n\n"
                                    md+="  ⌚"+ datetime.strftime(timeNow,'%H:%M:%S')+"  📆 "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n"
                                    md+="   ʀᴜɴ "+waktu(eltime)+"\n"
                                    md+="╭━━━━━━━━━━━─\n「 line.me/ti/p/~orchi91 」\n╰━━━━━━━━━━━─"
                                cl.sendReplyMessage(msg_id, to, str(md))

                          if cmd == "me" or text.lower() == 'me':
                                ca = cl.getContact(msg._from)
                                lip = ("「𝖒𝖞 𝖓𝖆𝖒𝖊 𝖑𝖊𝖆」\n ") + ca.displayName
                                cl.sendMessage(to, lip),cl.sendContact(msg.to,sender)

                          if cmd == 'bypas on':
                              if Alphatlovers["bypas"] == True:
                                  cl.sendMessage(to,"𝖒𝖔𝖉𝖊 𝖇𝖞𝖕𝖆𝖘𝖘 𝖘𝖚𝖉𝖆𝖍 𝖆𝖐𝖙𝖎𝖋")
                              else:
                                  Alphatlovers["bypas"] = True
                                  cl.sendMessage(to,"𝖒𝖔𝖉𝖊 𝖇𝖞𝖕𝖆𝖘𝖘 𝖙𝖊𝖑𝖆𝖍 𝖉𝖎𝖆𝖐𝖙𝖎𝖋𝖐𝖆𝖓")

                          if cmd == 'bypas off':
                              if Alphatlovers["bypas"] == False:
                                  cl.sendMessage(to,"bypass was off")
                              else:
                                  Alphatlovers["bypas"] = False
                                  cl.sendMessage(to,"bypass disable mode")

                          if "gname " in cmd:
                                X = cl.getGroup(msg.to)
                                X.name = msg.text.replace("gname ","")
                                cl.updateGroup(X)

                          if "mid " in cmd:
                               if 'MENTION' in msg.contentMetadata.keys()!= None:
                                   names = re.findall(r'@(\w+)', text)
                                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                   mentionees = mention['MENTIONEES']
                                   lists = []
                                   for mention in mentionees:
                                       if mention["M"] not in lists:
                                           lists.append(mention["M"])
                                   ret_ = ""
                                   for ls in lists:
                                       ret_ += "{}".format(str(ls))
                                   cl.sendMessage(to, str(ret_),{'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+'M', 'AGENT_NAME': 'Mention', 'AGENT_LINK': 'http://line.me/ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getProfile().picturePath})

                          if "info " in cmd:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                               key = ast.literal_eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "• Nama : "+str(mi.displayName)+"\n• Mid : " +key1+"\n• Status Msg"+str(mi.statusMessage))
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                          if cmd == "myrechat":
                               try:cl.removeAllMessages(op.param2)
                               except:pass

                          if cmd == "reject":
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      cl.rejectGroupInvitation(gid)
                                  cl.sendReplyMessage(msg_id, to, "ʙᴇʀʜᴀsɪʟ ᴛᴏʟᴀᴋ sᴇʙᴀɴʏᴀᴋ {} ᴜɴᴅᴀɴɢᴀɴ ɢʀᴜᴘ".format(str(len(ginvited))))
                              else:
                                  cl.sendReplyMessage(msg_id, to, "ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴜɴᴅᴀɴɢᴀɴ ʏᴀɴɢ ᴛᴇʀᴛᴜɴᴅᴀ")

                          if cmd == "leave allgrup":
                            group = cl.getGroupIdsJoined()
                            for i in group:
                                cl.sendMessage(i,"ʙᴏᴛ ʟᴇᴀᴠᴇ ᴀʟʟ ɢʀᴏᴜᴘ ")
                                cl.leaveGroup(i)
                                cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ʟᴇᴀᴠᴇ ᴀʟʟ ɢʀᴜᴘ")
                          if cmd.startswith("openqr no "):
                                if msg.toType == 2:
                                    text = cmd.split(" ")
                                    number = text[2]
                                    if number.isdigit():
                                        groups = cl.getGroupIdsJoined()
                                        if int(number) < len(groups) and int(number) >= 0:
                                            groupid = groups[int(number)]
                                            try:
                                                X = cl.getGroup(groupid)
                                                X.preventedJoinByTicket = False
                                                cl.updateGroup(X)
                                                gurl = cl.reissueGroupTicket(groupid)
                                                cl.sendMessage(msg.to,"This link Group For u can it Bro... \nline://ti/g/" + gurl)
                                            except:
                                                cl.sendMessage(msg.to," Gagal Bro ")
                          if cmd.startswith("leave to "):
                                text = cmd.split(" ")
                                number = text[2]
                                if number.isdigit():
                                    groups = cl.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)]
                                        try:
                                            groupname = cl.getGroup(groupid).name
                                            cl.leaveGroup(groupid)
                                            cl.sendMessage(msg.to,"Successfully  Leave from %s"%groupname)
                                        except:
                                            cl.sendMessage(msg.to," Leave Gagal Bro ")
                          if cmd == "rechat":
                              for i in [cl]:
                                  Rchat(i,to)
                          if cmd.startswith("bcg: "):
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   cl.sendMessage(group,"[ ʙʀᴏᴀᴅᴄᴀsᴛ ]\n" + str(pesan))
                          if cmd == "mykey":
                               cl.sendMessage(msg.to, "ᴋᴇʏ ɴᴏᴡ「 " + str(Alphatlovers["keyCmd"]) + " 」")
                          if cmd.startswith("setkey "):
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "ᴄʜᴀɴɢᴇ ᴋᴇʏ ғᴀɪʟᴇᴅ")
                               else:
                                   Alphatlovers["keyCmd"] = str(key).lower()
                                   cl.sendMessage(msg.to, "sᴜᴄᴄᴇs ᴀᴅᴅ ᴋᴇʏ ᴛᴏ「{}」".format(str(key).lower()))
                          if cmd == "resetkey":
                               Alphatlovers["keyCmd"]=""
                               cl.sendMessage(msg.to, "sᴜᴄᴄᴇs ʀᴇssᴇᴛ ᴋᴇʏ ᴄᴏᴍᴍᴀɴᴅ")
                          if cmd == "/reboot":
                               cl.sendMessage(msg.to, "ᴡᴀɪᴛɪɴɢ ᴀ sᴇᴄᴏɴᴅ")
                               restartProgram()
                          if cmd == "ginfo":
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "тєятυтυρ"
                                    gTicket = "тı∂αk α∂α"
                                else:
                                    gQr = "тєявυkα"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                cl.sendMessage(msg.to, "  •⌻「gяυρ ıηƒσ」⌻•\n\n ηαмα gяσυρ : {}".format(G.name)+ "\nı∂ gяσυρ : {}".format(G.id)+ "\ncяєαтσя gяσυρ : {}".format(G.creator.displayName)+ "\ncяєαтє тıмє gяσυρ : {}".format(str(timeCreated))+ "\nłısтмємвєя : {}".format(str(len(G.members)))+ "\nłısт ıηѵıтє : {}".format(gPending)+ "\ngяσυρ qя : {}".format(gQr)+ "\nтıckєт gяσυρ : {}".format(gTicket))
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                cl.sendMessage(msg.to, str(e))
                          if cmd.startswith("infogrup"):
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "No file"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "  •⌻ List Grup Info ⌻•\n"
                                ret_ += "\n⌬ Nama Group : {}".format(G.name)
                                ret_ += "\n⌬ ID Group : {}".format(G.id)
                                ret_ += "\n⌬ Pembuat : {}".format(gCreator)
                                ret_ += "\n⌬ Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n⌬ Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n⌬ Jumlah Pending : {}".format(gPending)
                                ret_ += "\n⌬ Group Qr : {}".format(gQr)
                                ret_ += "\n⌬ Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(to, str(ret_))
                            except:
                                pass
                          if cmd.startswith("infomem"):
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "● "+ str(no) + ". " + mem.displayName
                                cl.sendMessage(to,"● Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\n「Total %i Members」" % len(G.members))
                            except:
                                pass
                          if cmd == "friendlist":
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               cl.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")
                          if cmd == "gruplist":
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                          if cmd == "ourl":
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                cl.sendMessage(msg.to,"line://ti/g/" + gurl)
                          if cmd == "curl":
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   cl.sendMessage(msg.to, "ᴅᴏɴᴇ ᴄʟᴏsᴇ ǫʀ°")
#===========================================#
                          if cmd == "runtime":
                                eltime = time.time() - mulai
                                cl.sendMessage(to, "Bot Run : "+eltime)
                          if cmd == "pictgrup":
                              if msg.toType == 2:
                                Alphatlovers["gPicture"] = True
                                cl.sendMessage(msg.to,"ᴘʟᴇᴀsᴇ sᴇɴᴅ ᴘɪᴄᴛ")
                          if cmd == "updp bot":
                                Alphatlovers["DPicture"] = True
                                cl.sendMessage(msg.to,"ᴘʟᴇᴀsᴇ sᴇɴᴅ ᴘɪᴄᴛ")
                          if 'dpbot ' in cmd:
                              spl = cmd.replace('dpbot ','')
                              if spl == 'me':
                                  Alphatlovers["cPicture"][mid] = True
                                  cl.sendMessage(msg.to,"ᴘʟᴇᴀsᴇ sᴇɴᴅ ᴘɪᴄᴛ")
                              if spl == 'kicker':
                                  Alphatlovers["cPicture"][Smid] = True
                                  k1.sendMessage(msg.to, "ᴘᴇʟᴀsᴇ sᴇɴᴅ ᴘɪᴄᴛ ʙᴏss")
                          if cmd.startswith("name: "):
                            separate = text.split(" ")
                            string = text.replace(separate[0] + " ","")
                            if string == "":
                               setKey = "" if not Alphatlovers['keyCmd'] else Alphatlovers['keyCmd']
                            else:
                               setKey = string
                            profile = cl.getProfile()
                            profile.displayName = string
                            cl.updateProfile(profile)
                            cl.sendMessage(msg.to,"Succes " + str(string) + "")
                          if cmd.startswith("kcn: "):
                            separate = text.split(" ")
                            string = text.replace(separate[0] + " ","")
                            if string == "":
                               setKey = "" if not Alphatlovers['keyCmd'] else Alphatlovers['keyCmd']
                            else:
                               setKey = string
                            profile = k1.getProfile()
                            profile.displayName = string
                            k1.updateProfile(profile)
                            k1.sendMessage(msg.to,"Succes " + str(string) + "")
                          if cmd == "tag" or text.lower() == 'mention':
                                group = cl.getGroup(msg.to)
                                k = len(group.members)//20
                                for j in range(k+1):
                                    aa = []
                                    for x in group.members[j*20 : (j+1)*20]:
                                        aa.append(x.mid)
                                    try:
                                        arrData = ""
                                        textx = "╔══════════════════\n╠• . "
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += "╠• . ".format(str(b))
                                            else:
                                                textx += "╚══════════════════\n╔══════════════════\n  「 ᴛᴏᴛᴀʟ ᴍᴇᴍʙᴇʀ : {} 」\n╚══════════════════".format(str(len(aa)))
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))

                                                except:
                                                    no = " "
                                        msg.to = msg.to
                                        msg.text = textx
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage(to, textx,{'AGENT_NAME':'[ Mentions ]', 'AGENT_LINK': 'line://ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getProfile().picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                                    except Exception as e:
                                        cl.sendText(msg.to,str(e))
                          if cmd == "bots":
                                ma = ""
                                a = 0
                                for m_id in Alphatlovers["Bots"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"| じisτ B̶ѳτઽ •\n\n"+ma+"τσταℓ : 「%s」 B̶ѳτઽ" %(str(len(LiproSett["Bots"]))))
                          if cmd == "adminlist":
                                mb = ""
                                b = 0
                                for m_id in Alphatlovers["admin"]:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"| α∂мiท вστs •\n\n"+mb+"\nτσταℓ :「%s」 α∂мiท" %(str(len(LiproSett["admin"]))))
                          if cmd == "respon":
                              for i in [cl]:
                                  Res(i,to)
                          if cmd == "rs":
                              a = cl.getContact(msg._from).displayName
                              cl.sendMessage(to, "ｻⅰ "+ a)
                          if cmd == 'midku':
                              cl.sendMessage(msg.to,mid+'","'+Smid)
                          if 'lp ' in cmd:
                              spl = cmd.replace('lp ','')
                              for i in [cl]:
                                  i.sendMessage(msg.to,spl)
                          if cmd == "jsrespon":
                              a = cl.getContact(msg._from).displayName
                              k1.sendMessage(to, "ｻⅰ "+ a)
                          if cmd == "jsjoin":
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G.preventedJoinByTicket = True
                                cl.updateGroup(G)
                          if cmd.startswith("bypass"):
                                try:
                                    jser = threading.Thread(target=ProsesJs, args=(to, wait["Member"])).start()
                                except:
                                    cl.sendMessage(to,"Gagal BroW")
                          if cmd.startswith("qr no "):
                                if msg.toType == 2:
                                    text = cmd.split(" ")
                                    number = text[2]
                                    if number.isdigit():
                                        groups = cl.getGroupIdsJoined()
                                        if int(number) < len(groups) and int(number) >= 0:
                                            groupid = groups[int(number)]
                                            try:
                                                X = cl.getGroup(groupid)
                                                X.preventedJoinByTicket = False
                                                cl.updateGroup(X)
                                                gurl = cl.reissueGroupTicket(groupid)
                                                cl.sendMessage(msg.to,"This link Group For u can it Bro... \nline://ti/g/" + gurl)
                                            except:
                                                cl.sendMessage(msg.to," Gagal Bro ")

                          if cmd.startswith("clean "):
                              txtt = cmd.split(" ")
                              number = txtt[2]
                              if number.isdigit():
                                  groups = cl.getGroupIdsJoined()
                                  if int(number) < len(groups) and int(number) >= 0:
                                      groupid = groups[int(number)]
                                      for dhe in [cl]:
                                        try:
                                            x = cl.getGroup(groupid)
                                            anu = x.id
                                            if x.invitee == None:nama = []
                                            else:nama = [contact.mid for contact in x.invitee]
                                            targets = []
                                            for a in nama:
                                              if a not in Leakiller:
                                                targets.append(a)
                                            nami = [contact.mid for contact in x.members]
                                            targetk = []
                                            cms = 'dual.js gid={} token={}'.format(anu,dhe.authToken)
                                            for a in nami:
                                              if a not in Leakiller:
                                                targetk.append(a)
                                            for y in targets:
                                                cms += ' uid={}'.format(y)
                                            for y in targetk:
                                                cms += ' uik={}'.format(y)
                                            success = execute_js(cms)
                                            cl.sendMessage(to,'mínggír kαlíαn kíkíl ѕσngσng...')
                                            if x.preventedJoinByTicket == True:
                                                x.preventedJoinByTicket = False
                                                cl.updateGroup(x)
                                            gurl = cl.reissueGroupTicket(group)
                                            cl.sendMessage(to, 'join boss.. \n\nhttp://line.me/R/ti/g/'+gurl+'')
                                        except:
                                            cl.sendMessage(to, "gagal execusi")

                          if cmd == 'lea':
                            for dhe in [cl]:
                              try:
                                  x = cl.getGroup(to)
                                  if x.invitee == None:nama = []
                                  else:nama = [contact.mid for contact in x.invitee]
                                  targets = []
                                  for a in nama:
                                      if a not in Leakiller:
                                          targets.append(a)
                                  nami = [contact.mid for contact in x.members]
                                  targetk = []
                                  cms = 'dual.js gid={} token={}'.format(to,anu.authToken)
                                  for a in nami:
                                      if a not in Leakiller:
                                          targetk.append(a)
                                  for y in targets:
                                      cms += ' uid={}'.format(y)
                                  for y in targetk:
                                      cms += ' uik={}'.format(y)
                                  success = execute_js(cms)
                                  cl.sendMessage(to,'mínggír kαlíαn kíkíl ѕσngσng...')
                              except:
                                  print("gagal")
                          if cmd.startswith("nuke no "):
                                if msg.toType == 0:
                                    text = cmd.split(" ")
                                    number = text[2]
                                    if number.isdigit():
                                        groups = cl.getGroupIdsJoined()
                                        if int(number) < len(groups) and int(number) >= 0:
                                            groupid = groups[int(number)]
                                            try:
                                                for hk in [k1]:
                                                    X = cl.getGroup(groupid)
                                                    desi = X.id
                                                    if X.invitee == None:nama = []
                                                    else:nama = [contact.mid for contact in X.invitee]
                                                    target = []
                                                    for a in nama:
                                                        if a not in Leakiller:
                                                            target.append(a)
                                                    cmd = 'bypass.js gid={} token={}'.format(anu, hk.authToken)
                                                    d = [o.mid for o in X.members]
                                                    tarsem = []
                                                    for s in d:
                                                        if s not in Leakiller:
                                                            tarsem.append(s)
                                                    for y in target:
                                                        cmd += ' uid={}'.format(y)
                                                    for k in tarsem:
                                                        cmd += ' uid={}'.format(k)
                                                    success = execute_js(cmd)
                                                    X.preventedJoinByTicket = False
                                                    cl.updateGroup(X)
                                                    gurl = cl.reissueGroupTicket(groupid)
                                                    cl.sendMessage(to,"This link Group For u can it Bro... \nline://ti/g/" + gurl)
                                            except:cl.sendMessage(to,"Sorry i'cant nuker this numb room")
                          if cmd == "js stay":
                                try:
                                    cl.inviteIntoGroup(msg.to,Lea)
                                except:
                                    cl.sendMessage(msg.to,"antijs sudah stay di pendingan\nor bot limit")
                          if cmd == "ajscancel":
                                    cl.cancelGroupInvitation(msg.to,[Lea])
                          if cmd == "jsbye":
                                G = k1.getGroup(msg.to)
                                k1.sendMessage(msg.to, "sєє υ мємвєя "+str(G.name))
                                k1.leaveGroup(msg.to)
                          if cmd == "/bye":
                                G = cl.getGroup(msg.to)
                                cl.sendMessage(msg.to, "❂➤ sєє υ мємвєя  "+str(G.name))
                                try:
                                    k1.acceptGroupInvitation(msg.to)
                                    cl.leaveGroup(msg.to)
                                    k1.leaveGroup(msg.to)
                                except:
                                    cl.leaveGroup(msg.to)
                          if cmd == "speed" or cmd == "sp":
                                jb=[cl]
                                for i in jb:
                                    Speed(i,to)
                          if cmd == "lurk on":
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Alphatlovers['readPoint'][msg.to] = msg_id
                                 Alphatlovers['readMember'][msg.to] = {}
                                 cl.sendMessage(msg.to, "Lurking berhasil diaktifkan\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                          if cmd == "lurk off":
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Alphatlovers['readPoint'][msg.to]
                                 del Alphatlovers['readMember'][msg.to]
                                 cl.sendMessage(msg.to, "Lurking berhasil dinoaktifkan\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                          if cmd == "lurkers":
                            if msg.to in Alphatlovers['readPoint']:
                                if Alphatlovers['readMember'][msg.to] != {}:
                                    aa = []
                                    for x in Alphatlovers['readMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\n⌬ Tanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n⌚ Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage1(msg)
                                    except:
                                        pass
                                    try:
                                        del Alphatlovers['readPoint'][msg.to]
                                        del Alphatlovers['readMember'][msg.to]
                                    except:
                                        pass
                                    Alphatlovers['readPoint'][msg.to] = msg.id
                                    Alphatlovers['readMember'][msg.to] = {}
                                else:
                                    cl.sendMessage(msg.to, "User kosong...")
                            else:
                                cl.sendMessage(msg.to, "Ketik lurking on ")
                          if cmd == "sider on":
                              try:
                                  cl.sendMessage(msg.to, "ᴄʜᴇᴄᴋ sɪᴅᴇʀ ᴍᴇᴍʙᴇʀ ᴀʟʟʀᴇᴀᴅʏ ᴏɴ")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True
                          if cmd == "sider off":
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  cl.sendMessage(msg.to, "ᴄʜᴇᴄᴋ sɪᴅᴇʀ ᴍᴇᴍʙᴇʀ ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                              else:
                                  cl.sendMessage(msg.to, "ᴄʜᴇᴄᴋ sɪᴅᴇʀ ᴍᴇᴍʙᴇʀ ᴡᴀs ᴏғғ")
                          if cmd.startswith("max: "):
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Alphatlovers["Maxlimit"] = num
                                cl.sendMessage(msg.to,"ᴀʟʟʀᴇᴀᴅʏ sᴘᴀᴍ ᴍᴇɴᴛɪᴏɴ ɪɴ :" +strnum)
                          if cmd.startswith("scall: "):
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Alphatlovers["limit"] = num
                                cl.sendMessage(msg.to,"ᴀʟʟʀᴇᴀᴅʏ sᴘᴀᴍ ᴄᴀʟʟ ɪɴ :" +strnum)
                          if cmd.startswith("stag "):
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = ast.literal_eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Alphatlovers["Maxlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendMessage(msg.to,str(e))
                                    else:
                                        cl.sendMessage(msg.to,"Jumlah melebihi 1000")
                          if cmd == "scall":
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(Alphatlovers["limit"])
                                cl.sendMessage(to, "sᴜᴄᴄᴇs sᴇɴᴅ {} sᴘᴀᴍ ᴄᴀʟʟ".format(str(LiproSett["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                         cl.acquireGroupCallRoute(to)
                                         cl.inviteIntoGroupCall(to, contactIds=members)
                                     except:
                                         pass
                                else:
                                    cl.sendMessage(to,"Jumlah melebihi batas")
                          if 'id line: ' in cmd:
                              msgs = cmd.replace('id line: ','')
                              conn = cl.findContactsByUserid(msgs)
                              if True:
                                  cl.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  cl.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)
                          if 'welcome ' in cmd:
                              spl = cmd.replace('welcome ','')
                              if spl == 'on':
                                  if msg.to in Alphatlovers["welcome"]:
                                       msgs = "ᴡᴀs ᴏɴ"
                                  else:
                                       Alphatlovers["welcome"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏɴ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「sᴇɴᴅ ᴍᴇssᴀɢᴇ ᴡᴇʟᴄᴏᴍᴇ」" + msgs)
                              elif spl == 'off':
                                    if msg.to in Alphatlovers["welcome"]:
                                         del Alphatlovers["welcome"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏғғ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴡᴀs ᴏғғ"
                                    cl.sendMessage(msg.to, "「sᴇɴᴅ ᴍᴇssᴀɢᴇ ᴡᴇʟᴄᴏᴍᴇ 」" + msgs)
                          if 'left ' in cmd:
                              spl = cmd.replace('left ','')
                              if spl == 'on':
                                  if msg.to in Alphatlovers["leaveMsg"]:
                                       msgs = "ᴡᴀs ᴏɴ"
                                  else:
                                       Alphatlovers["leaveMsg"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏɴ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「sᴇɴᴅ ᴍᴇssᴀɢᴇ ʟᴇᴀᴠᴇ」" + msgs)
                              elif spl == 'off':
                                    if msg.to in Alphatlovers["leaveMsg"]:
                                         del Alphatlovers["leaveMsg"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏғғ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴡᴀs ᴏғғ"
                                    cl.sendMessage(msg.to, "「sᴇɴᴅ ᴍᴇssᴀɢᴇ ʟᴇᴀᴠᴇ」" + msgs)
                          if 'proqr ' in cmd:
                              spl = cmd.replace('proqr ','')
                              if spl == 'on':
                                  if msg.to in Alphatlovers["proqr"]:
                                       msgs = "ᴡᴀs ᴏɴ"
                                  else:
                                       Alphatlovers["proqr"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏɴ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「ᴘʀᴏᴛᴇᴄᴛɪᴏɴ ʟɪɴᴋ」" + msgs)
                              elif spl == 'off':
                                    if msg.to in Alphatlovers["proqr"]:
                                         del Alphatlovers["proqr"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏғғ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴡᴀs ᴏғғ"
                                    cl.sendMessage(msg.to, "「ᴘʀᴏᴛᴇᴄᴛɪᴏɴ ʟɪɴᴋ」" + msgs)
                          if 'prokick ' in cmd:
                              spl = cmd.replace('prokick ','')
                              if spl == 'on':
                                  if msg.to in Alphatlovers["proKick"]:
                                       msgs = "ᴡᴀs ᴏɴ"
                                  else:
                                       Alphatlovers["proKick"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏɴ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「ᴘʀᴏᴛᴇᴄᴛ ᴋɪᴄᴋ」" + msgs)
                              elif spl == 'off':
                                    if msg.to in Alphatlovers["proKick"]:
                                         del Alphatlovers["proKick"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏғғ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴡᴀs ᴏғғ"
                                    cl.sendMessage(msg.to, "「ᴘʀᴏᴛᴇᴄᴛ ᴋɪᴄᴋ」" + msgs)
                          if 'proinvite ' in cmd:
                              spl = cmd.replace('proinvite ','')
                              if spl == 'on':
                                  if msg.to in Alphatlovers["proInvite"]:
                                       msgs = "ᴡᴀs ᴏɴ"
                                  else:
                                       Alphatlovers["proInvite"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏɴ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「ᴘʀᴏᴛᴇᴄᴛ ɪɴᴠɪᴛᴇ」" + msgs)
                              elif spl == 'off':
                                    if msg.to in Alphatlovers["proInvite"]:
                                         del Alphatlovers["proInvite"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏғғ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴡᴀs ᴏғғ"
                                    cl.sendMessage(msg.to, "「ᴘʀᴏᴛᴇᴄᴛ ɪɴᴠɪᴛᴇ」" + msgs)
                          if 'procancel ' in cmd:
                              spl = cmd.replace('procancel ','')
                              if spl == 'on':
                                  if msg.to in Alphatlovers["proCancel"]:
                                       msgs = "ᴡᴀs ᴏɴ"
                                  else:
                                       Alphatlovers["proCancel"] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏɴ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「ᴘʀᴏᴛᴇᴄᴛ ᴄᴀɴᴄᴇʟ」" + msgs)
                              elif spl == 'off':
                                    if msg.to in Alphatlovers["proCancel"]:
                                         Alphatlovers["proCancel"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏғғ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴡᴀs ᴏғғ"
                                    cl.sendMessage(msg.to, "「ᴘʀᴏᴛᴇᴄᴛ ᴄᴀɴᴄᴇʟ」" + msgs)
                          if 'protect ' in cmd:
                              spl = cmd.replace('protect ','')
                              if spl == 'on':
                                  if msg.to in Alphatlovers["proqr"]:
                                       msgs = ""
                                  else:
                                       Alphatlovers["proqr"][msg.to] = True
                                  if msg.to in Alphatlovers["proKick"]:
                                      msgs = ""
                                  else:
                                       Alphatlovers["proKick"][msg.to] = True
                                  if msg.to in Alphatlovers["proInvite"]:
                                      msgs = ""
                                  else:
                                       Alphatlovers["proInvite"][msg.to] = True
                                  if msg.to in Alphatlovers["proCancel"]:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "ᴡᴀs ᴏɴ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  else:
                                       Alphatlovers["proCancel"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏɴ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「ᴀʟʟ ᴘʀᴏᴛᴇᴄᴛɪᴏɴ」" + msgs)
                              elif spl == 'off':
                                    if msg.to in Alphatlovers["proqr"]:
                                         del Alphatlovers["proqr"][msg.to]
                                    else:
                                         msgs = ""
                                    if msg.to in Alphatlovers["proKick"]:
                                         del Alphatlovers["proKick"][msg.to]
                                    else:
                                         msgs = ""
                                    if msg.to in Alphatlovers["proInvite"]:
                                         del Alphatlovers["proInvite"][msg.to]
                                    else:
                                         msgs = ""
                                    if msg.to in Alphatlovers["proCancel"]:
                                         del Alphatlovers["proCancel"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏғғ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴡᴀs ᴏғғ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    cl.sendMessage(msg.to, "「ᴀʟʟ ᴘʀᴏᴛᴇᴄᴛɪᴏɴ」" + msgs)
                          if 'inta ' in cmd:
                              spl = cmd.replace('inta ','')
                              if spl == 'on':
                                  if msg.to in Alphatlovers["intaPoint"]:
                                       msgs = "ᴡᴀs ᴏɴ"
                                  else:
                                       Alphatlovers["intaPoint"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏɴ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「ɪɴᴛᴀ ᴘᴏɪɴᴛ」" + msgs)
                              elif spl == 'off':
                                    if msg.to in Alphatlovers["intaPoint"]:
                                         del Alphatlovers["intaPoint"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟʀᴇᴀᴅʏ ᴏғғ ɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴡᴀs ᴏғғ"
                                    cl.sendMessage(msg.to, "「ɪɴᴛᴀ ᴘᴏɪɴᴛ」" + msgs)
                          if "bot kick " in cmd:
                              if 'MENTION' in msg.contentMetadata.keys():
                                  mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                                  for mention in mentions['MENTIONEES']:
                                      uid = mention['M']
                                      if uid in Zie or uid in Bots or uid in Alphatlovers["Bots"]:
                                          continue
                                      try:
                                          cl.kickoutFromGroup(msg.to, [uid])
                                          wait["blacklist"][uid] = True
                                      except:
                                          cl.sendMessage(msg.to,"ʟɪᴍɪᴛʙᴏsᴋᴜʜ")
                          if "invite" in cmd:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                               key = ast.literal_eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in wait["blacklist"]:
                                       cl.sendMessage(msg.to, "sᴏʀʀʏ ᴄᴏɴᴛᴀᴄᴛ ɪɴ ʙʟᴀᴄᴋʟɪsᴛ")
                                   else:
                                       try:
                                           cl.findAndAddContactsByMid(target)
                                           cl.inviteIntoGroup(msg.to, [target])
                                       except:
                                           cl.sendMessage(msg.to, "sᴏʀʀʏ!! ᴛᴀʀɢᴇᴛ ɪɴᴠɪᴛᴇ ɴᴏᴛ ғᴏᴜɴᴅ ᴏʀ ʙᴏᴛs ʟɪᴍɪᴛ ɪɴᴠɪᴛᴇ")(msg.to, "sᴏʀʀʏ!! ᴛᴀʀɢᴇᴛ ɪɴᴠɪᴛᴇ ɴᴏᴛ ғᴏᴜɴᴅ ᴏʀ ʙᴏᴛs ʟɪᴍɪᴛ ɪɴᴠɪᴛᴇ")

                          if "kiss " in cmd:
                              if 'MENTION' in msg.contentMetadata.keys():
                                  mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                                  for mention in mentions['MENTIONEES']:
                                      uid = mention['M']
                                      if uid in Zie or uid in Bots or uid in Alphatlovers["Bots"]:
                                          continue
                                      try:
                                          cl.kickoutFromGroup(msg.to, [uid])
                                      except:
                                          cl.sendMessage(msg.to,"ʟɪᴍɪᴛʙᴏsᴋᴜʜ")
                          if "@cancelin" in cmd:
                               group = cl.getGroup(msg.to)
                               if group.invitee is None:
                                   cl.sendMessage(op.message.to, "kσsσηg вσss ")
                               else:
                                   nama = [contact.mid for contact in group.invitee]
                                   for x in nama:
                                     if x not in Zie and x not in Bots and x not in Alphatlovers["Bots"] and x not in LiproSett["admin"]:
                                       cl.cancelGroupInvitation(msg.to, [x])
                                       time.sleep(0.3)
                                   cl.sendMessage(to, "∂σηє.")
                          if "bot cancel" in cmd:
                               group = cl.getGroup(msg.to)
                               if group.invitee is None:
                                   cl.sendMessage(op.message.to, "kσsσηg вσss ")
                               else:
                                   k1.acceptGroupInvitation(msg.to)
                                   nama = [contact.mid for contact in group.invitee]
                                   for x in nama:
                                     for j in [k1]:
                                       if x not in Zie and x not in Bots and x not in Alphatlovers["Bots"] and x not in LiproSett["admin"]:
                                         j.cancelGroupInvitation(msg.to, [x])
                                         time.sleep(0.3)
                                   cl.sendMessage(to, "∂σηє.")
                          if "addadmin " in cmd:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                               key = ast.literal_eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in Alphatlovers["admin"]:
                                       cl.sendMessage(msg.to,"ωαs ıη α∂мıη")
                                   else:
                                       try:
                                           Alphatlovers["admin"][target] = True
                                           cl.sendMessage(msg.to,"sυccєs α∂∂ α∂мıη")
                                       except:
                                           pass
                          if "addbot " in cmd:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                               key = ast.literal_eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in Alphatlovers["Bots"]:
                                       cl.sendMessage(msg.to,"ωαs ıη вσтs")
                                   else:
                                       try:
                                           Alphatlovers["Bots"][target] = True
                                           cl.sendMessage(msg.to,"sυccєs α∂∂ вσтs")
                                       except:
                                           pass
                          if "deladmin " in cmd:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                               key = ast.literal_eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Alphatlovers["admin"]:
                                       cl.sendMessage(msg.to,"ησт ıη α∂мıη")
                                   else:
                                       try:
                                           del Alphatlovers["admin"][target]
                                           cl.sendMessage(msg.to,"sυccєs ∂єłєтє α∂мıη")
                                       except:
                                           pass
                          if "delbot " in cmd:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                               key = ast.literal_eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Alphatlovers["Bots"]:
                                       cl.sendMessage(msg.to,"ησт ıη ʙᴏᴛs")
                                   else:
                                       try:
                                           del Alphatlovers["Bots"][target]
                                           cl.sendMessage(msg.to,"sυccєs ∂єłєтє вσтs")
                                       except:
                                           pass
                          if cmd.startswith("join to "):
                                text = cmd.split(" ")
                                number = text[2]
                                if number.isdigit():
                                    groups = cl.getGroupIdsJoined()
                                    if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)]
                                        try:
                                            cl.findAndAddContactsByMid(sender)
                                            cl.inviteIntoGroup(groupid,[sender])
                                            groupname = cl.getGroup(groupid).name
                                            cl.sendMessage(msg.to,"Successfully invite %s"%groupname)
                                        except:
                                            cl.sendMessage(msg.to," Invite banned Bro " + cl.getContact(sender).displayName)

                          if cmd == "groups":
                                gid = cl.getGroupIdsJoined()
                                num = 0
                                g = ""
                                for i in gid:
                                    g += "%i - " % num + "%s" % (cl.getGroup(i).name + "(%s)\n" % (str (len (cl.getGroup(i).members))))
                                    num = (num+1)
                                cl.sendMessage(msg.to,"Group List:\n\n"+ g + "Total Groups : " + str(len(gid)))

                          if cmd == "cbot" or text.lower() == 'clear bot':
                              ang = cl.getContacts(Alphatlovers["Bots"])
                              mc = "%i вστs " % len(ang)
                              cl.sendMessage(msg.to,"ᴅᴏɴᴇ ᴄʟᴇᴀʀ " +mc)
                              Alphatlovers["Bots"] = {}
                          if cmd == "cadmin" or text.lower() == 'clear admin':
                              ang = cl.getContacts(LiproSett["admin"])
                              mc = "%i ᴀᴅᴍɪɴ " % len(ang)
                              cl.sendMessage(msg.to,"ᴅᴏɴᴇ ᴄʟᴇᴀʀ " +mc)
                              Alphatlovers["admin"] = {}
                          if cmd == "admin:on" or text.lower() == 'admin:on':
                                Alphatlovers["addadmin"] = True
                                cl.sendMessage(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ...")
                          if cmd == "admin:del" or text.lower() == 'admin:del':
                                Alphatlovers["deladmin"] = True
                                cl.sendMessage(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ...")
                          if cmd == "admin:off" or text.lower() == 'admin off':
                                Alphatlovers["addadmin"] = False
                                cl.sendMessage(msg.to,"ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "deladmin:off" or text.lower() == 'deladmin off':
                                Alphatlovers["deladmin"] = False
                                cl.sendMessage(msg.to,"ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "bot:on" or text.lower() == 'bot on':
                                Alphatlovers["abots"] = True
                                cl.sendMessage(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ...")
                          if cmd == "bot:off" or text.lower() == 'bot off':
                                Alphatlovers["abots"] = False
                                cl.sendMessage(msg.to,"ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "bot:del" or text.lower() == 'bot del':
                                Alphatlovers["dbots"] = True
                                cl.sendMessage(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ...")
                          if cmd == "delbot:off" or text.lower() == 'delbot off':
                                Alphatlovers["dbots"] = False
                                cl.sendMessage(msg.to,"ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "allrefresh" or text.lower() == 'refresh':
                                Alphatlovers["addadmin"] = False
                                Alphatlovers["deladmin"] = False
                                Alphatlovers["abots"] = False
                                Alphatlovers["dbots"] = False
                                Alphatlovers["ablacklist"] = False
                                Alphatlovers["dblacklist"] = False
                                Alphatlovers["LikeOn"] = False
                                cl.sendMessage(msg.to," ❂ вσt вєrhαѕíl dírєfrєѕh ❂")
                          if cmd == "killban":
                                if msg.toType == 2:
                                    group = cl.getGroup(msg.to)
                                    gMembMids = [contact.mid for contact in group.members]
                                    matched_list = []
                                    for tag in wait["blacklist"]:
                                        matched_list+=filter(lambda str: str == tag, gMembMids)
                                    if matched_list == []:
                                        pass
                                    for jj in matched_list:
                                        try:
                                            klist=[ka,kb,kc,kd,ke,kf]
                                            kicker=random.choice(klist)
                                            kicker.kickoutFromGroup(msg.to,[jj])
                                            print (msg.to,[jj])
                                        except:
                                            pass
                          if cmd == "ctbot" or text.lower() == 'ctbot':
                                ma = ""
                                for i in Alphatlovers["Bots"]:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                          if cmd == "ctban" or text.lower() == 'ctbanlist':
                                ma = ""
                                for i in wait["blacklist"]:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                          if cmd == "contact:on" or text.lower() == 'contact on':
                                Alphatlovers["contact"] = True
                                cl.sendMessage(msg.to,"ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟ ᴄᴏɴᴛᴀᴄᴛ ᴀʟʟʀᴇᴀᴅʏ ᴏɴ")
                          if cmd == "contact:off" or text.lower() == 'contact off':
                                Alphatlovers["contact"] = False
                                cl.sendMessage(msg.to,"ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟ ᴄᴏɴᴛᴀᴄᴛ ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "respon:on" or text.lower() == 'respon on':
                                Alphatlovers["detectMention"] = True
                                cl.sendMessage(msg.to,"ʀᴇsᴘᴏɴ ᴍᴇɴᴛɪᴏɴ ᴀʟʟʀᴇᴀᴅʏ ᴏɴ")
                          if cmd == "respon:off" or text.lower() == 'respon off':
                                Alphatlovers["detectMention"] = False
                                cl.sendMessage(msg.to,"ʀᴇsᴘᴏɴ ᴍᴇɴᴛɪᴏɴ ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "autojoin:on" or text.lower() == 'autojoin on':
                                Alphatlovers["autoJoin"] = True
                                cl.sendMessage(msg.to,"ᴀᴜᴛᴏᴊᴏɪɴ ᴀʟʟʀᴇᴀᴅʏ ᴏɴ")
                          if cmd == "autojoin:off" or text.lower() == 'autojoin off':
                                Alphatlovers["autoJoin"] = False
                                cl.sendMessage(msg.to,"ᴀᴜᴛᴏᴊᴏɪɴ ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "like:on" or text.lower() == 'like on':
                              Alphatlovers["LikeOn"] = True
                              cl.sendMessage(msg.to,"ᴀᴜᴛᴏʟɪᴋᴇ ᴀʟʟʀᴇᴀᴅʏ ᴏɴ")
                          if cmd == "like:off" or text.lower() == 'like off':
                              Alphatlovers["LikeOn"] = False
                              cl.sendMessage(msg.to,"ᴀᴜᴛᴏʟɪᴋᴇ ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "scan:on" or text.lower() == 'scan on':
                                Alphatlovers["checkmid"] = True
                                cl.sendMessage(msg.to,"ᴄʜᴇᴄᴋ ᴍɪᴅ ᴄᴏɴᴛᴀᴄᴛ ᴀʟʟʀᴇᴀᴅʏ ᴏɴ")
                          if cmd == "scan:off" or text.lower() == 'scan off':
                                Alphatlovers["checkmid"] = False
                                cl.sendMessage(msg.to,"ᴄʜᴇᴄᴋ ᴍɪᴅ ᴄᴏɴᴛᴀᴄᴛ ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "post:on" or text.lower() == 'post on':
                                Alphatlovers["checkPost"] = True
                                cl.sendMessage(msg.to,"ᴅᴇᴛᴇᴄᴛ ᴘᴏsᴛ ᴀʟʟʀᴇᴀᴅʏ ᴏɴ")
                          if cmd == "post:off" or text.lower() == 'post off':
                                Alphatlovers["checkPost"] = False
                                cl.sendMessage(msg.to,"ᴅᴇᴛᴇᴄᴛ ᴘᴏsᴛ ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "unsend:on" or text.lower() == 'unsend on':
                                Alphatlovers["Unsend"] = True
                                cl.sendMessage(msg.to,"ᴅᴇᴛᴇᴄᴛ ᴜɴsᴇɴᴅ ᴍᴇssᴀɢᴇ ᴀʟʟʀᴇᴅʏ ᴏɴ")
                          if cmd == "unsend:off" or text.lower() == 'unsend off':
                                Alphatlovers["Unsend"] = False
                                cl.sendMessage(msg.to,"ᴅᴇᴛᴇᴄᴛ ᴜɴsᴇɴᴅ ᴍᴇssᴀɢᴇ ᴀʟʟʀᴇᴅʏ ᴏғғ")
                          if cmd == "autoadd:on" or text.lower() == 'autoadd on':
                                Alphatlovers["autoAdd"] = True
                                cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴀᴅᴅ ᴀʟʟʀᴇᴅʏ ᴏɴ")
                          if cmd == "autoadd:off" or text.lower() == 'autoadd off':
                                Alphatlovers["autoAdd"] = False
                                cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴀᴅᴅ ᴀʟʟʀᴇᴅʏ ᴏғғ")
                          if cmd == "sticker:on" or text.lower() == 'sticker on':
                                Alphatlovers["sticker"] = True
                                cl.sendMessage(msg.to,"ᴄʜᴇᴄᴋ sᴛɪᴄᴋᴇʀ ᴀʟʟʀᴇᴅʏ ᴏɴ")
                          if cmd == "sticker:off" or text.lower() == 'sticker off':
                                Alphatlovers["sticker"] = False
                                cl.sendMessage(msg.to,"ᴄʜᴇᴄᴋ sᴛɪᴄᴋᴇʀ ᴀʟʟʀᴇᴅʏ ᴏғғ")
                          if cmd == "jticket:on" or text.lower() == 'jticket on':
                                Alphatlovers["autoJoinTicket"] = True
                                cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴊᴏɪɴ ᴛɪᴄᴋᴇᴛ ᴀʟʟʀᴇᴅʏ ᴏɴ")
                          if cmd == "jticket:off" or text.lower() == 'jticket off':
                                Alphatlovers["autoJoinTicket"] = False
                                cl.sendMessage(msg.to,"ᴀᴜᴛᴏ ᴊᴏɪɴ ᴛɪᴄᴋᴇᴛ ᴀʟʟʀᴇᴅʏ ᴏғғ")
                          if "ban " in cmd:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                               key = ast.literal_eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in wait["blacklist"]:
                                       cl.sendMessage(msg.to,"ᴄᴏɴᴛᴀᴄᴛ ᴡᴀs ɪɴ ʙʟᴀᴄᴋʟɪsᴛ")
                                   else:
                                       try:
                                           wait["blacklist"][target] = True
                                           cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ᴀᴅᴅ ᴛᴏ ʙʟᴀᴄᴋʟɪsᴛ")
                                       except:
                                           pass
                          if "delbl " in cmd:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                               key = ast.literal_eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in wait["blacklist"]:
                                       cl.sendMessage(msg.to,"ᴄᴏɴᴛᴀᴄᴛ ɴᴏᴛ ɪɴ ʙʟᴀᴄᴋʟɪsᴛ")
                                   else:
                                       try:
                                           del wait["blacklist"][target]
                                           cl.sendMessage(msg.to,"sᴜᴄᴄᴇs ʀᴇᴍᴏᴠᴇ ɪɴ ʙʟᴀᴄᴋʟɪsᴛ")
                                       except:
                                           pass
                          if cmd == "ban:on" or text.lower() == 'ban on':
                                Alphatlovers["ablacklist"] = True
                                cl.sendMessage(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ...")
                          if cmd == "ban:off" or text.lower() == 'ban off':
                                Alphatlovers["ablacklist"] = False
                                cl.sendMessage(msg.to,"ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "unban:on" or text.lower() == 'unban on':
                                Alphatlovers["dblacklist"] = True
                                cl.sendMessage(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ...")
                          if cmd == "unban:off" or text.lower() == 'unban off':
                                Alphatlovers["dblacklist"] = False
                                cl.sendMessage(msg.to,"ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")
                          if cmd == "banlist" or text.lower() == 'blacklist':
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"| Terciduk ●\n\n"+ma+"\nTotal : 「%s」 Terciduk " %(str(len(wait["blacklist"]))))
                          if cmd == "cban" or text.lower() == 'cban':
                              ang = cl.getContacts(wait["blacklist"])
                              mc = "%i Tersangka " % len(ang)
                              cl.sendMessage(msg.to,"Di Ampuni " +mc)
                              wait["blacklist"] = {}
                          if 'add: ' in cmd:
                              ang = cmd.replace('add: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Alphatlovers["message"] = ang
                                  cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ ᴀᴅᴅ」 :\n\n「{}」".format(str(ang)))
                          if 'left: ' in cmd:
                              ang = cmd.replace('left: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Alphatlovers["leftmsg"] = ang
                                  cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ ʟᴇᴀᴠᴇ」 :\n\n「{}」".format(str(ang)))
                          if 'welcome: ' in cmd:
                              ang = cmd.replace('welcome: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Alphatlovers["sambutan"] = ang
                                  cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ ᴡᴇʟʟᴄᴏᴍᴇ」 :\n\n「{}」".format(str(ang)))
                          if 'tag: ' in cmd:
                              ang = cmd.replace('tag: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Alphatlovers["msgTag"] = ang
                                  cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ ᴍᴇɴᴛɪᴏɴ」:\n\n「{}」".format(str(ang)))
                          if 'spam: ' in cmd:
                              ang = cmd.replace('spam: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Alphatlovers["spamMsg"] = ang
                                  cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ sᴘᴀᴍ」 :\n\n「{}」".format(str(ang)))
                          if 'sider: ' in cmd:
                              znf = cmd.replace('sider: ','')
                              if znf in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Alphatlovers["siderMsg"] = znf
                                  cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ sɪᴅᴇʀ」:\n\n「{}」".format(str(znf)))
                          if 'invmid ' in cmd:
                              znf = cmd.replace('invmid ','')
                              try:
                                  cl.findAndAddContactsByMid(znf)
                                  cl.sendContact(to,znf)
                              except Exception as e:
                                  traceback.print_exc()
                                  
                          if cmd == "cekmsg":
                               cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ ᴀᴅᴅ」 :\n「 " + str(Alphatlovers["message"]) + " 」")
                               cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ sɪᴅᴇʀ」:\n「 " + str(Alphatlovers["siderMsg"]) + " 」")
                               cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ ᴍᴇɴᴛɪᴏɴ」:\n「 " + str(Alphatlovers["msgTag"]) + " 」")
                               cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ sᴘᴀᴍ」:\n「 " + str(Alphatlovers["spamMsg"]) + " 」")
                               cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ ᴡᴇʟʟᴄᴏᴍᴇ」:\n「 " + str(Alphatlovers["sambutan"]) + " 」")
                               cl.sendMessage(msg.to, "「ᴍᴇssᴀɢᴇ ʟᴇᴀᴠᴇ」:\n「 " + str(Alphatlovers["leftmsg"]) + " 」")
#===========JOIN TICKET============#
                          if "/ti/g/" in msg.text.lower():
                              if Alphatlovers["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 gids = cl.getGroupIdsJoined()
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     try:
                                         group = cl.findGroupByTicket(ticket_id)
                                     except:
                                         continue
                                     if group in gids:
                                         continue

                          if msg.text.lower() in ["check"]:
                                oncom = ["uafee8af1c47101fa12ae93e28da1ec80"] #MID PUSKUN
                                for _mid in oncom:
                                    try:cl.inviteIntoGroup(msg.to,[_mid]);cl.sendMessage(msg.to,"kαmí ѕєmuα rєαdч вσѕѕquh")
                                    except:cl.sendMessage(msg.to,"╔────── ¤ 𝖐𝖔𝖓𝖉𝖎𝖘𝖎 𝖇𝖔𝖙𝖘 ¤ ──────╗\n♻️👉 𝐤𝐚𝐦𝐢 𝐫𝐞𝐚𝐝𝐲 𝐛𝐨𝐬𝐬𝐪𝐮𝐡\n╚────── ¤ 𝐫𝐞𝐚𝐝𝐲 𝐠𝐨 ¤ ──────╝")
                                    k1.acceptGroupInvitation(msg.to)
                                    try:k1.inviteIntoGroup(msg.to,[_mid]);k1.sendMessage(msg.to,"kαmí ѕєmuα rєαdч вσѕѕquh")
                                    except:k1.sendMessage(msg.to,"╔────── ¤ 𝖐𝖔𝖓𝖉𝖎𝖘𝖎 𝖇𝖔𝖙𝖘 ¤ ──────╗\n♻️👉 𝖘𝖊𝖉𝖆𝖓𝖌 𝖑𝖎𝖒𝖎𝖙 𝖇𝖔𝖘𝖘𝖖𝖚𝖍\n╚────── ¤ 𝖏𝖆𝖓𝖌𝖆𝖓 𝖉𝖎𝖕𝖆𝖐𝖘𝖆 ¤ ──────╝")
                                    k1.leaveGroup(msg.to)

      except Exception as e:
          print(e)

def Flist(self,to):
    ma = "╭━━━━━━━━━━━─\n╰─⟦ Friend List ⟧\n\n"
    a = 0
    gid = self.getAllContactIds()
    for i in gid:
        G = self.getContact(i)
        a = a + 1
        end = "\n"
        ma += "∘· " + str(a) + ". " +G.displayName+ "\n"
    self.sendMessage(to,ma+"\n╭──「 "+str(len(gid))+"  Friends  」\n╰━━━━━━━━━━━─")
def Sp(self,to):
      get_group_time_start = time.time()
      get_group = self.getGroupIdsJoined()
      get_group_time = time.time() - get_group_time_start
      self.sendMessage(to, "[ ~G : %.4f ⚡]" % (get_group_time/2))

def Speed(self,to):
      get_group_time_start = time.time()
      get_group = self.getGroupIdsJoined()
      get_group_time = time.time() - get_group_time_start
      get_contact_time_start = time.time()
      get_contact = self.getContact(mid)
      get_contact_time = time.time() - get_contact_time_start
      get_profile_time_start = time.time()
      get_profile = self.getProfile()
      get_profile_time = time.time() - get_profile_time_start
      self.sendMessage(to, "[ ~P : %.4f ⚡]\n[ ~C : %.4f ⚡]\n[ ~G : %.4f ⚡]" % (get_profile_time/2,get_contact_time/2,get_group_time/2))

def likePost(self, mid, postId, likeType=1001):
    if mid is None:
        mid = cl.profile.mid
    if likeType not in [1001,1002,1003,1004,1005,1006]:
        raise Exception('Invalid parameter likeType')
    params = {'homeId': mid, 'sourceType': 'TIMELINE'}
    url = cl.server.urlEncode(cl.server.LINE_TIMELINE_API, '/v23/like/create', params)
    data = {'likeType': likeType, 'postId': postId, 'actorId': mid}
    r = cl.server.postContent(url, data=data, headers=cl.server.channelHeaders)
    return r.json()

def createComment(self, mid, postId, text):
    if mid is None:
        mid = self.profile.mid
    params = {'homeId': mid, 'sourceType': 'TIMELINE'}
    url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/comment/create.json', params)
    data = {'commentText': text, 'activityExternalId': postId, 'actorId': mid}
    data = json.dumps(data)
    r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
    return r.json()

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "「reader {} member」\nhai ka.. ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+Alphatlovers["siderMsg"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "「Member Join {}」\Wellcome ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+Alphatlovers["sambutan"]+"\ndi group : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

while True:
    try:
        ops = linePoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                    linePoll.setRevision(op.revision)
                    thread = threading.Thread(target=bot, args=(op,))
                    thread.start()
    except Exception as e:
        print(e)

